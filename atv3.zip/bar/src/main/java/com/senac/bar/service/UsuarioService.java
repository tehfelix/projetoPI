package com.senac.bar.service;

import com.senac.bar.model.Usuario;
import com.senac.bar.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {
    private final UsuarioRepository usuarioRepository;
    

public Optional<Usuario> autenticar(String username, String senha) {
    return usuarioRepository.findByUsernameAndSenha(username, senha);
}


    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> buscarPorId(Long id) {
        return usuarioRepository.findById(id);
    }
    public void alternarStatus(Long id) {
    usuarioRepository.findById(id).ifPresent(usuario -> {
        usuario.setAtivo(!usuario.isAtivo()); // Alterna entre ativo e inativo
        usuarioRepository.save(usuario);
    });
    
}


    public Usuario salvarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Usuario atualizarUsuario(Long id, Usuario usuarioAtualizado) {
        return usuarioRepository.findById(id).map(usuario -> {
            usuario.setUsername(usuarioAtualizado.getUsername());
            usuario.setSenha(usuarioAtualizado.getSenha());
            usuario.setPerfil(usuarioAtualizado.getPerfil());
            usuario.setAtivo(usuarioAtualizado.isAtivo());
            return usuarioRepository.save(usuario);
        }).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }
    public List<Usuario> listarTodos() {
    return usuarioRepository.findAll();
}


    public void desativarUsuario(Long id) {
        usuarioRepository.findById(id).ifPresent(usuario -> {
            usuario.setAtivo(false);
            usuarioRepository.save(usuario);
        });
    }
}
