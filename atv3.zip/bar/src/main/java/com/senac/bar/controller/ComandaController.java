package com.senac.bar.controller;

import com.senac.bar.model.Comanda;
import com.senac.bar.model.ItemComanda;
import com.senac.bar.service.ComandaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comandas")
public class ComandaController {
    private final ComandaService comandaService;

    public ComandaController(ComandaService comandaService) {
        this.comandaService = comandaService;
    }

    @GetMapping
    public List<Comanda> listarComandas() {
        return comandaService.listarTodas();
    }

    @PostMapping
    public Comanda criarComanda(@RequestBody Comanda comanda) {
        return comandaService.criarComanda(comanda);
    }

    @PostMapping("/{id}/itens")
    public ResponseEntity<ItemComanda> adicionarItem(@PathVariable Long id, @RequestBody ItemComanda item) {
        return ResponseEntity.ok(comandaService.adicionarItem(id, item));
    }

    @PutMapping("/{id}/fechar")
    public ResponseEntity<Void> fecharComanda(@PathVariable Long id) {
        comandaService.fecharComanda(id);
        return ResponseEntity.noContent().build();
    }
}
