package com.senac.bar.controller;

import com.senac.bar.model.Usuario;
import com.senac.bar.service.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController // ✅ Agora retorna JSON corretamente
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:3000") // Permite chamadas do front-end
public class AuthController {
    private final UsuarioService usuarioService;

    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> autenticarUsuario(@RequestBody Usuario usuario) {
        if (usuario.getUsername() == null || usuario.getSenha() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Usuário e senha são obrigatórios.");
        }

        Optional<Usuario> usuarioEncontrado = usuarioService.autenticar(usuario.getUsername(), usuario.getSenha());

        if (usuarioEncontrado.isPresent()) {
            return ResponseEntity.ok(usuarioEncontrado.get()); // Retorna usuário autenticado
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuário ou senha incorretos!");
        }
    }
}
