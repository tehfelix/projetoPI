package com.senac.bar.controller;

import com.senac.bar.model.Produto;
import com.senac.bar.service.ProdutoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {
    private final ProdutoService produtoService;
    
    

    public ProdutoController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @GetMapping
    public List<Produto> listarProdutos() {
        return produtoService.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Produto> buscarProduto(@PathVariable Long id) {
        return produtoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Produto criarProduto(@RequestBody Produto produto) {
        return produtoService.salvar(produto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Produto> atualizarProduto(@PathVariable Long id, @RequestBody Produto produto) {
        Produto atualizado = produtoService.atualizar(id, produto);
        return ResponseEntity.ok(atualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirProduto(@PathVariable Long id) {
        produtoService.excluir(id);
        return ResponseEntity.noContent().build();
    }

@PutMapping("/abastecer/{id}")
public ResponseEntity<Produto> abastecerProduto(
    @PathVariable Long id, 
    @RequestBody Map<String, Object> estoqueAtualizado
) {
    try {
        int estoqueInterno = Integer.parseInt(estoqueAtualizado.getOrDefault("estoqueInterno", "0").toString());
        int estoqueVenda = Integer.parseInt(estoqueAtualizado.getOrDefault("estoqueVenda", "0").toString());

        Produto atualizado = produtoService.abastecerEstoque(id, estoqueInterno, estoqueVenda);
        return ResponseEntity.ok(atualizado);

    } catch (Exception e) {
        e.printStackTrace(); // 🔹 EXIBE ERRO NO CONSOLE CASO ALGO DÊ ERRADO
        return ResponseEntity.badRequest().body(null);
    }
}



}
