package com.senac.bar.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "comandas")
public class Comanda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nomeCliente;
    private boolean fechada = false;
    
    @OneToMany(mappedBy = "comanda", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemComanda> itens;

    // Construtores
    public Comanda() {}
    
    public Comanda(String nomeCliente) {
        this.nomeCliente = nomeCliente;
        this.fechada = false;
    }
    
    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNomeCliente() { return nomeCliente; }
    public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }
    
    public boolean isFechada() { return fechada; }
    public void setFechada(boolean fechada) { this.fechada = fechada; }
    
    public List<ItemComanda> getItens() { return itens; }
    public void setItens(List<ItemComanda> itens) { this.itens = itens; }
}
