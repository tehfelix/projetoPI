package com.senac.bar.model;

import jakarta.persistence.*;

@Entity
@Table(name = "produtos")
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nome;

    private String descricao;

    @Column(nullable = false)
    private String grupo;  

    private int volume;

    private String tipoVolume;

    @Column(nullable = false)
    private int estoqueInterno = 0;

    @Column(nullable = false)
    private int estoqueVenda = 0;

    // ✅ Construtor Padrão
    public Produto() {
    }

    // ✅ Construtor com parâmetros
    public Produto(String nome, String descricao, String grupo, int volume, String tipoVolume) {
        this.nome = nome;
        this.descricao = descricao;
        this.grupo = grupo;
        this.volume = volume;
        this.tipoVolume = tipoVolume;
        this.estoqueInterno = 0;
        this.estoqueVenda = 0;
    }

    // ✅ Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getTipoVolume() {
        return tipoVolume;
    }

    public void setTipoVolume(String tipoVolume) {
        this.tipoVolume = tipoVolume;
    }

    public int getEstoqueInterno() {
        return estoqueInterno;
    }

    public void setEstoqueInterno(int estoqueInterno) {
        this.estoqueInterno = estoqueInterno;
    }

    public int getEstoqueVenda() {
        return estoqueVenda;
    }

    public void setEstoqueVenda(int estoqueVenda) {
        this.estoqueVenda = estoqueVenda;
    }

    // ✅ Método toString para exibir informações do produto
    @Override
    public String toString() {
        return "Produto{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", descricao='" + descricao + '\'' +
                ", grupo='" + grupo + '\'' +
                ", volume=" + volume +
                ", tipoVolume='" + tipoVolume + '\'' +
                ", estoqueInterno=" + estoqueInterno +
                ", estoqueVenda=" + estoqueVenda +
                '}';
    }
}
