package com.senac.bar.service;

import com.senac.bar.model.Comanda;
import com.senac.bar.model.ItemComanda;
import com.senac.bar.repository.ComandaRepository;
import com.senac.bar.repository.ItemComandaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ComandaService {
    private final ComandaRepository comandaRepository;
    private final ItemComandaRepository itemComandaRepository;

    public ComandaService(ComandaRepository comandaRepository, ItemComandaRepository itemComandaRepository) {
        this.comandaRepository = comandaRepository;
        this.itemComandaRepository = itemComandaRepository;
    }

    public List<Comanda> listarTodas() {
        return comandaRepository.findAll();
    }

    public Optional<Comanda> buscarPorId(Long id) {
        return comandaRepository.findById(id);
    }

    public Comanda criarComanda(Comanda comanda) {
        return comandaRepository.save(comanda);
    }

    public ItemComanda adicionarItem(Long comandaId, ItemComanda item) {
        return comandaRepository.findById(comandaId).map(comanda -> {
            item.setComanda(comanda);
            return itemComandaRepository.save(item);
        }).orElseThrow(() -> new RuntimeException("Comanda não encontrada"));
    }

    public void fecharComanda(Long id) {
        comandaRepository.findById(id).ifPresent(comanda -> {
            comanda.setFechada(true);
            comandaRepository.save(comanda);
        });
    }
}
