package com.senac.bar.model;

import jakarta.persistence.*;

@Entity
@Table(name = "itens_comanda")
public class ItemComanda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nomeProduto;
    private int quantidade;
    private boolean pago;
    private boolean cortesia;
    
    @ManyToOne
    @JoinColumn(name = "comanda_id", nullable = false)
    private Comanda comanda;

    // Construtores
    public ItemComanda() {}
    
    public ItemComanda(String nomeProduto, int quantidade, Comanda comanda) {
        this.nomeProduto = nomeProduto;
        this.quantidade = quantidade;
        this.comanda = comanda;
        this.pago = false;
        this.cortesia = false;
    }
    
    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNomeProduto() { return nomeProduto; }
    public void setNomeProduto(String nomeProduto) { this.nomeProduto = nomeProduto; }
    
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    
    public boolean isPago() { return pago; }
    public void setPago(boolean pago) { this.pago = pago; }
    
    public boolean isCortesia() { return cortesia; }
    public void setCortesia(boolean cortesia) { this.cortesia = cortesia; }
    
    public Comanda getComanda() { return comanda; }
    public void setComanda(Comanda comanda) { this.comanda = comanda; }
}
