package com.senac.bar.service;

import com.senac.bar.model.Produto;
import com.senac.bar.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {
    private final ProdutoRepository produtoRepository;

    public ProdutoService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public List<Produto> listarTodos() {
        return produtoRepository.findAll();
    }

    public Optional<Produto> buscarPorId(Long id) {
        return produtoRepository.findById(id);
    }

    public Produto salvar(Produto produto) {
        produto.setEstoqueInterno(0); // Inicia estoque interno com 0
        produto.setEstoqueVenda(0); // Inicia estoque venda com 0
        return produtoRepository.save(produto);
    }

    public Produto atualizar(Long id, Produto produtoAtualizado) {
        return produtoRepository.findById(id).map(produto -> {
            produto.setNome(produtoAtualizado.getNome());
            produto.setDescricao(produtoAtualizado.getDescricao());
            produto.setGrupo(produtoAtualizado.getGrupo());
            produto.setVolume(produtoAtualizado.getVolume());
            produto.setTipoVolume(produtoAtualizado.getTipoVolume());
            return produtoRepository.save(produto);
        }).orElseThrow(() -> new RuntimeException("Produto não encontrado"));
    }


public Produto abastecerEstoque(Long id, int estoqueInterno, int estoqueVenda) {
    return produtoRepository.findById(id).map(produto -> {
        produto.setEstoqueInterno(produto.getEstoqueInterno() + estoqueInterno);
        produto.setEstoqueVenda(produto.getEstoqueVenda() + estoqueVenda);
        return produtoRepository.save(produto); // 🔹 GARANTE que a atualização será salva no banco
    }).orElseThrow(() -> new RuntimeException("Produto não encontrado"));
}







    public void excluir(Long id) {
        produtoRepository.deleteById(id);
    }
}
