package com.senac.bar.controller;

import com.senac.bar.model.Usuario;
import com.senac.bar.service.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Controller // ✅ Agora o Spring entende que este controlador retorna páginas HTML
@RequestMapping("/usuarios")
public class UsuarioController {
    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // ✅ Método correto para carregar a página usuarios.html com a lista de usuários
    @GetMapping
    public String listarUsuarios(Model model) {
        List<Usuario> usuarios = usuarioService.listarUsuarios();
        model.addAttribute("usuarios", usuarios);
        return "usuarios"; // Certifique-se de que existe o arquivo src/main/resources/templates/usuarios.html
    }

    // ✅ Retorna um usuário específico em JSON (para chamadas AJAX, se necessário)
    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Usuario> buscarUsuario(@PathVariable Long id) {
        return usuarioService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ✅ API para criar um usuário (usada em AJAX/formulários)
    @PostMapping
    @ResponseBody
    public Usuario criarUsuario(@RequestBody Usuario usuario) {
        return usuarioService.salvarUsuario(usuario);
    }

    // ✅ API para atualizar um usuário
    @PutMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Usuario> atualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        Usuario atualizado = usuarioService.atualizarUsuario(id, usuario);
        return ResponseEntity.ok(atualizado);
    }

    @PutMapping("/{id}/status")
public ResponseEntity<Void> alternarStatusUsuario(@PathVariable Long id) {
    usuarioService.alternarStatus(id);
    return ResponseEntity.noContent().build();
}
@PostMapping("/login")
public ResponseEntity<?> autenticarUsuario(@RequestBody Usuario usuario) {
    Optional<Usuario> usuarioEncontrado = usuarioService.autenticar(usuario.getUsername(), usuario.getSenha());

    if (usuarioEncontrado.isPresent()) {
        return ResponseEntity.ok(usuarioEncontrado.get());
    } else {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuário ou senha incorretos!");
    }
}
    
    // ✅ API para desativar um usuário
    @PutMapping("/{id}/desativar")
    @ResponseBody
    public ResponseEntity<Void> desativarUsuario(@PathVariable Long id) {
        usuarioService.desativarUsuario(id);
        return ResponseEntity.noContent().build();
    }
}
