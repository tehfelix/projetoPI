package com.senac.bar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
    @GetMapping("/login")
    public String exibirTelaLogin() {
        return "login";  // Certifique-se de que login.html está em templates/
    }
}
