document.addEventListener("DOMContentLoaded", function () {
    carregarProdutos();

    document.getElementById("botaoSalvarProduto").addEventListener("click", function () {
        let id = document.getElementById("botaoSalvarProduto").getAttribute("data-id");
        if (id) {
            salvarEdicaoProduto(id);
        } else {
            salvarProduto();
        }
    });
});

function carregarProdutos() {
    fetch("/produtos")
        .then(response => response.json())
        .then(produtos => {
            let lista = document.getElementById("listaProdutos");
            lista.innerHTML = "";
            produtos.forEach(produto => {
                let totalEstoque = (produto.estoqueVenda ?? 0) + (produto.estoqueInterno ?? 0);
                lista.innerHTML += `
                    <tr>
                        <td>${produto.nome}</td>
                        <td>${produto.grupo}</td>
                        <td>${produto.volume} ${produto.tipoVolume}</td>
                        <td>${totalEstoque}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editarProduto(${produto.id})">✏️ Editar</button>
                            <button class="btn btn-danger btn-sm" onclick="excluirProduto(${produto.id})">🗑️ Excluir</button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => console.error("Erro ao carregar produtos:", error));
}

function abrirCadastroProduto() {
    limparFormulario(); // Garante que os campos estejam limpos ao cadastrar novo produto
    document.getElementById("botaoSalvarProduto").removeAttribute("data-id"); // Remove ID para novo cadastro

    let modal = new bootstrap.Modal(document.getElementById("cadastroProduto"));
    modal.show();
}

function fecharCadastroProduto() {
    let modalEl = document.getElementById("cadastroProduto");
    let modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
}

function salvarProduto() {
    let produto = {
        nome: document.getElementById("nomeProduto").value.trim(),
        descricao: document.getElementById("descricaoProduto").value.trim(),
        grupo: document.getElementById("grupoProduto").value,
        volume: parseInt(document.getElementById("volumeProduto").value),
        tipoVolume: document.getElementById("tipoVolumeProduto").value,
        estoqueInterno: 0,
        estoqueVenda: 0
    };

    if (!produto.nome) {
        alert("O nome do produto é obrigatório!");
        return;
    }

    fetch("/produtos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(produto)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro ao cadastrar produto");
            }
            return response.json();
        })
        .then(() => {
            alert("Produto cadastrado com sucesso!");
            fecharCadastroProduto();
            carregarProdutos();
        })
        .catch(error => console.error("Erro ao cadastrar produto:", error));
}

function editarProduto(id) {
    fetch(`/produtos/${id}`)
        .then(response => response.json())
        .then(produto => {
            if (!produto) {
                console.error("Produto não encontrado!");
                return;
            }
            
            // Preencher os campos do modal com os dados do produto
            document.getElementById("nomeProduto").value = produto.nome;
            document.getElementById("descricaoProduto").value = produto.descricao;
            document.getElementById("grupoProduto").value = produto.grupo;
            document.getElementById("volumeProduto").value = produto.volume;
            document.getElementById("tipoVolumeProduto").value = produto.tipoVolume;
            
            document.getElementById("botaoSalvarProduto").setAttribute("data-id", id);

            // **Abrir o modal APÓS carregar os dados**
            let modal = new bootstrap.Modal(document.getElementById("cadastroProduto"));
            modal.show();
        })
        .catch(error => console.error("Erro ao carregar produto para edição:", error));
}

function salvarEdicaoProduto(id) {
    let produto = {
        nome: document.getElementById("nomeProduto").value.trim(),
        descricao: document.getElementById("descricaoProduto").value.trim(),
        grupo: document.getElementById("grupoProduto").value,
        volume: parseInt(document.getElementById("volumeProduto").value),
        tipoVolume: document.getElementById("tipoVolumeProduto").value
    };

    fetch(`/produtos/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(produto)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro na atualização do produto");
            }
            return response.json();
        })
        .then(() => {
            alert("Produto atualizado com sucesso!");
            fecharCadastroProduto();
            carregarProdutos();
        })
        .catch(error => console.error("Erro ao atualizar produto:", error));
}

function excluirProduto(id) {
    if (confirm("Tem certeza que deseja excluir este produto?")) {
        fetch(`/produtos/${id}`, { method: "DELETE" })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erro ao excluir produto");
                }
                alert("Produto excluído com sucesso!");
                carregarProdutos();
            })
            .catch(error => console.error("Erro ao excluir produto:", error));
    }
}

function limparFormulario() {
    document.getElementById("nomeProduto").value = "";
    document.getElementById("descricaoProduto").value = "";
    document.getElementById("grupoProduto").value = "Bebida";
    document.getElementById("volumeProduto").value = "";
    document.getElementById("tipoVolumeProduto").value = "mL";
}
