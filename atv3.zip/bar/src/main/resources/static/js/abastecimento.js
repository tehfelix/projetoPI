document.addEventListener("DOMContentLoaded", function () {
    carregarProdutos();
});

function carregarProdutos() {
    fetch("/produtos")
        .then(response => response.json())
        .then(produtos => {
            let lista = document.getElementById("listaProdutos");
            lista.innerHTML = "";
            produtos.forEach(produto => {
                lista.innerHTML += `
                    <tr>
                        <td>${produto.nome}</td>
                        <td>${produto.grupo}</td>
                        <td>${produto.volume} ${produto.tipoVolume}</td>
                        <td>${produto.estoqueVenda ?? 0}</td>
                        <td>${produto.estoqueInterno ?? 0}</td>
                        <td>${(produto.estoqueVenda ?? 0) + (produto.estoqueInterno ?? 0)}</td>
                        <td>
                            <button class="btn btn-success btn-sm" onclick="abastecerProduto(${produto.id}, 'estoqueVenda')">📥Venda</button>
                            <button class="btn btn-primary btn-sm" onclick="abastecerProduto(${produto.id}, 'estoqueInterno')">📦Interno</button>
                            <button class="btn btn-warning btn-sm" onclick="transferirEstoque(${produto.id})">🔄 Transferir</button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => console.error("Erro ao carregar produtos:", error));
}

function abastecerProduto(id, tipoEstoque) {
    let quantidade = parseInt(prompt("Quantidade a abastecer:"), 10);
    
    if (isNaN(quantidade) || quantidade <= 0) {
        alert("Entrada inválida!");
        return;
    }

    let dados = { estoqueInterno: 0, estoqueVenda: 0 };
    if (tipoEstoque === "estoqueVenda") {
        dados.estoqueVenda = quantidade;
    } else if (tipoEstoque === "estoqueInterno") {
        dados.estoqueInterno = quantidade;
    }

    console.log("Enviando para o backend:", JSON.stringify(dados));

    fetch(`/produtos/abastecer/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dados)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Erro ao abastecer produto");
        }
        return response.json();
    })
    .then(data => {
        console.log("Resposta do backend:", data);
        atualizarProdutoNaTabela(data);
        alert("Produto abastecido com sucesso!");
    })
    .catch(error => console.error("Erro ao abastecer produto:", error));
}

// 🔄 Função para transferir do estoque interno para venda 🔄
function transferirEstoque(id) {
    let quantidade = parseInt(prompt("Quantidade a transferir para venda:"), 10);
    
    if (isNaN(quantidade) || quantidade <= 0) {
        alert("Entrada inválida!");
        return;
    }

    let dados = { estoqueInterno: -quantidade, estoqueVenda: quantidade };

    console.log("Transferindo para o backend:", JSON.stringify(dados));

    fetch(`/produtos/abastecer/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dados)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Erro ao transferir estoque");
        }
        return response.json();
    })
    .then(data => {
        console.log("Resposta do backend:", data);
        atualizarProdutoNaTabela(data);
        alert("Transferência realizada com sucesso!");
    })
    .catch(error => console.error("Erro ao transferir estoque:", error));
}

// 🔹 Atualiza a linha do produto na tabela 🔹
function atualizarProdutoNaTabela(produto) {
    let lista = document.getElementById("listaProdutos");
    let linhas = lista.getElementsByTagName("tr");

    for (let i = 0; i < linhas.length; i++) {
        let colunaNome = linhas[i].getElementsByTagName("td")[0]; // Nome do produto
        if (colunaNome && colunaNome.innerText === produto.nome) {
            linhas[i].getElementsByTagName("td")[3].innerText = produto.estoqueVenda;
            linhas[i].getElementsByTagName("td")[4].innerText = produto.estoqueInterno;
            linhas[i].getElementsByTagName("td")[5].innerText = produto.estoqueVenda + produto.estoqueInterno;
            return;
        }
    }
    carregarProdutos();
}
