document.addEventListener("DOMContentLoaded", function () {
    carregarUsuarios();
});

function carregarUsuarios() {
    fetch("/usuarios")
        .then(response => response.json())
        .then(usuarios => {
            let lista = document.getElementById("listaUsuarios");
            lista.innerHTML = "";
            usuarios.forEach(usuario => {
                lista.innerHTML += `
                    <tr>
                        <td>${usuario.username}</td>
                        <td>${usuario.perfil}</td>
                        <td>${usuario.ativo ? '✅ Ativo' : '❌ Inativo'}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editarUsuario(${usuario.id})">✏️ Editar</button>
                            <button class="btn btn-danger btn-sm" onclick="excluirUsuario(${usuario.id})">🗑️ Excluir</button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => console.error("Erro ao carregar usuários:", error));
}

function abrirCadastroUsuario() {
    limparFormulario();
    document.getElementById("botaoSalvarUsuario").removeAttribute("data-id");
    let modal = new bootstrap.Modal(document.getElementById("cadastroUsuario"));
    modal.show();
}

function fecharCadastroUsuario() {
    let modalEl = document.getElementById("cadastroUsuario");
    let modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
}

function salvarUsuario() {
    let id = document.getElementById("botaoSalvarUsuario").getAttribute("data-id");
    let usuario = {
        username: document.getElementById("username").value.trim(),
        senha: document.getElementById("senha").value.trim(),
        perfil: document.getElementById("perfil").value,
        ativo: document.getElementById("ativo").checked
    };

    if (!usuario.username || !usuario.senha) {
        alert("Usuário e senha são obrigatórios!");
        return;
    }

    let url = id ? `/usuarios/${id}` : "/usuarios";
    let metodo = id ? "PUT" : "POST";

    fetch(url, {
        method: metodo,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(usuario)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro ao salvar usuário");
            }
            return response.json();
        })
        .then(() => {
            alert("Usuário salvo com sucesso!");
            fecharCadastroUsuario();
            carregarUsuarios();
        })
        .catch(error => console.error("Erro ao salvar usuário:", error));
}

function editarUsuario(id) {
    fetch(`/usuarios/${id}`)
        .then(response => response.json())
        .then(usuario => {
            document.getElementById("username").value = usuario.username;
            document.getElementById("senha").value = ""; // Não exibir senha por segurança
            document.getElementById("perfil").value = usuario.perfil;
            document.getElementById("ativo").checked = usuario.ativo;
            document.getElementById("botaoSalvarUsuario").setAttribute("data-id", id);
            abrirCadastroUsuario();
        })
        .catch(error => console.error("Erro ao carregar usuário para edição:", error));
}

function excluirUsuario(id) {
    if (confirm("Tem certeza que deseja excluir este usuário?")) {
        fetch(`/usuarios/${id}`, { method: "DELETE" })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erro ao excluir usuário");
                }
                alert("Usuário excluído com sucesso!");
                carregarUsuarios();
            })
            .catch(error => console.error("Erro ao excluir usuário:", error));
    }
}

function limparFormulario() {
    document.getElementById("username").value = "";
    document.getElementById("senha").value = "";
    document.getElementById("perfil").value = "vendedor";
    document.getElementById("ativo").checked = true;
}

