document.addEventListener("DOMContentLoaded", function () {
    let comandas = [];
    let comandaCount = 1;
    let produtosDisponiveis = [];

    // 🔹 Criar nova comanda
    window.novaComanda = function () {
        let nome = document.getElementById("nomeCliente").value.trim();
        if (nome === "") nome = "Cliente " + comandaCount;
        comandaCount++;

        let comanda = {
            id: Date.now(),
            nome: nome,
            itens: [],
            fechada: false
        };
        comandas.push(comanda);
        renderizarComandas();
    };

    // 🔹 Editar nome da comanda
    window.editarNomeComanda = function (event, comandaId) {
        let comanda = comandas.find(c => c.id === comandaId);
        if (!comanda) return;
        let novoNome = event.target.value.trim();
        if (novoNome !== "") comanda.nome = novoNome;
    };

    // 🔹 Abrir modal de produtos
    window.abrirModalProdutos = function (comandaId) {
        carregarProdutos();
        let modal = new bootstrap.Modal(document.getElementById("produtoModal"));
        modal.show();
        document.getElementById("listaProdutos").setAttribute("data-comanda-id", comandaId);
    };

    // 🔹 Carregar produtos da API
    function carregarProdutos() {
        fetch("/produtos")
            .then(response => response.json())
            .then(data => {
                produtosDisponiveis = data.filter(p => p.estoqueVenda > 0);
                exibirProdutos(produtosDisponiveis);
            })
            .catch(error => console.error("Erro ao carregar produtos:", error));
    }

    // 🔹 Exibir produtos no modal
    function exibirProdutos(produtos) {
        let lista = document.getElementById("listaProdutos");
        lista.innerHTML = "";
        produtos.forEach(produto => {
            let item = document.createElement("button");
            item.classList.add("list-group-item", "list-group-item-action");
            item.textContent = `${produto.nome} - ${produto.descricao} (${produto.volume} ${produto.tipoVolume})`;
            item.onclick = function () { selecionarProduto(produto); };
            lista.appendChild(item);
        });
    }

    // 🔹 Buscar produto no modal
    document.getElementById("buscaProduto").addEventListener("input", function () {
        let termo = this.value.toLowerCase();
        let produtosFiltrados = produtosDisponiveis.filter(p => 
            p.nome.toLowerCase().includes(termo) || p.descricao.toLowerCase().includes(termo)
        );
        exibirProdutos(produtosFiltrados);
    });

    // 🔹 Selecionar produto e definir quantidade
    function selecionarProduto(produto) {
        let quantidade = prompt(`Quantidade para ${produto.nome}:`, "1");
        if (!quantidade || isNaN(quantidade) || quantidade <= 0) return;

        let comandaId = document.getElementById("listaProdutos").getAttribute("data-comanda-id");
        let comanda = comandas.find(c => c.id == comandaId);
        if (!comanda) return;

        let item = { nome: produto.nome, quantidade: parseInt(quantidade), pago: false, cortesia: false };
        comanda.itens.push(item);
        renderizarComandas();
        salvarItemNoBanco(comandaId, item);
    }

    // 🔹 Salvar item no banco
    function salvarItemNoBanco(comandaId, item) {
        fetch(`/comandas/${comandaId}/itens`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(item)
        }).catch(error => console.error("Erro ao adicionar item:", error));
    }

    // 🔹 Renderizar comandas
    function renderizarComandas() {
        let container = document.getElementById("comandas");
        container.innerHTML = "";
        comandas.forEach(comanda => {
            if (comanda.fechada) return;

            let itensHtml = comanda.itens.map((item, index) => `
                <li class="list-group-item d-flex justify-content-between ${item.pago ? 'pago' : ''}">
                    <span>${item.quantidade}x ${item.nome}</span>
                    <div>
                        <input type="checkbox" ${item.pago ? "disabled checked" : ""} ${item.cortesia ? "disabled" : ""} onclick="selecionarItem('${comanda.id}', ${index}, 'pago')">
                        <span class="text-success">💲</span>
                        <input type="checkbox" ${item.pago ? "disabled" : ""} ${item.cortesia ? "checked" : ""} onclick="selecionarItem('${comanda.id}', ${index}, 'cortesia')">
                        <span class="text-warning">🎁</span>
                    </div>
                </li>
            `).join("");

            container.innerHTML += `
                <div class="comanda p-3">
                    <div class="comanda-header">
                        <input type="text" class="editable" value="${comanda.nome}" onblur="editarNomeComanda(event, '${comanda.id}')">
                        <button class="btn btn-danger btn-sm" onclick="fecharComanda('${comanda.id}')">❌ Fechar</button>
                    </div>
                    <ul class="list-group item-list mt-2">${itensHtml || "<li class='list-group-item'>Sem itens</li>"}</ul>
                    <button class="btn btn-success btn-sm w-100 mt-2" onclick="abrirModalProdutos('${comanda.id}')">➕ Adicionar Item</button>
                    <button class="btn btn-primary btn-sm w-100 mt-2" onclick="pagarSelecionados('${comanda.id}')">💰 Pagar Selecionados</button>
                </div>
            `;
        });
    }

    // 🔹 Selecionar item para pagar ou marcar cortesia
    window.selecionarItem = function (comandaId, itemIndex, tipo) {
        let comanda = comandas.find(c => c.id === comandaId);
        let item = comanda.itens[itemIndex];

        if (item.pago) return;

        if (tipo === "pago") {
            item.selecionado = !item.selecionado;
            if (item.selecionado) item.cortesia = false;
        } else if (tipo === "cortesia") {
            item.cortesia = !item.cortesia;
            if (item.cortesia) item.selecionado = false;
        }
        renderizarComandas();
    };

    // 🔹 Pagar itens selecionados
    window.pagarSelecionados = function (comandaId) {
        let comanda = comandas.find(c => c.id === comandaId);
        comanda.itens.forEach(item => {
            if (item.selecionado || item.cortesia) {
                item.pago = true;
                item.selecionado = false;
            }
        });
        renderizarComandas();
    };

    // 🔹 Fechar comanda
    window.fecharComanda = function (comandaId) {
        let comanda = comandas.find(c => c.id === comandaId);
        if (!comanda) return;

        let itensNaoPagos = comanda.itens.filter(item => !item.pago);
        if (itensNaoPagos.length > 0) {
            let justificativa = prompt("Existem itens não pagos. Informe a justificativa:");
            if (!justificativa) return;
        }

        comanda.fechada = true;
        renderizarComandas();
    };
});
